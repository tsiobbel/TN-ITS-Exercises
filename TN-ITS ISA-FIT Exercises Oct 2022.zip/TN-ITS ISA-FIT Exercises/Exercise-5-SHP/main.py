# Download Maximum Speeds from ESRI shape files from RWS server
# TN-ITS ISA-FIT training 13.10.2022
# Exercise 5 : download shape files
# Stephen T'Siobbel, ERTICO, 2022
# see tn-its.eu

# open text file with all urls for shape files
urlfile = open('rws.txt', 'r')

# initiate counter
count = 0

# set number of bytes to retrieve large binary files in chunks, avoiding to load them in memory entirely
chunk_size = 1000000

# loop over all urls available in the text file
while True:
    count += 1

    # Get line from text file where files are located
    urlline = urlfile.readline()

    # stop if line is empty
    if not urlline:
        break

    # extract path and filename from the urls in the list
    # remove any end of line characters
    # compose a new string to access the urls on the web
    # and write pdfs in subdirectory
    head, tail = os.path.split(urlline)
    head = head.replace("\n", "")
    tail = tail.replace("\n", "")
    newline = head + '/' + tail

    # show number of files and their name
    print(count, tail)

    # send a GET request to the specified url and store response in r
    r = requests.get(newline, stream=True)

    # write out the pdf files in bytes using their original file name
    with open(tail, 'wb') as fd:
        # do this in chunks so not to load them in memory entirely each time
        for chunk in r.iter_content(chunk_size):
           fd.write(chunk)
    fd.close()
urlfile.close()



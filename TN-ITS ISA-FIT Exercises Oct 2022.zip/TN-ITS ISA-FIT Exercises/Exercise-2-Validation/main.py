# Validation of XML instances against XSD schemas
# TN-ITS ISA-FIT training 13.10.2022
# Exercise 2 - Validation
# Stephen T'Siobbel, ERTICO, 2022
# see tn-its.eu

# import libraries
import xmlschema, datetime

# output date/time messages
def prtTimelog(strMsg):
    print(str(datetime.datetime.now()) + ' ' + strMsg)

# point to XSD schema file and XML file to validate
xsd_path = 'http://spec.tn-its.eu/schemas/TNITS.xsd'
xml_path = 'RWS-SEP-22.XML'

# get start time from windows and signal the validation started
startTime = datetime.datetime.now()
prtTimelog("Validating...")

# test a block of code for errors, validate throws an error if not met
try:
    xmlschema.validate(xml_path, xsd_path)
    prtTimelog('Valid!')
except Exception as e:
    prtTimelog('Not valid: ' + str(e))

# output messages
timePassed = datetime.datetime.now() - startTime
prtTimelog('----------- END -----------')
prtTimelog('Time passed: ' + str(timePassed.total_seconds()) + ' seconds')
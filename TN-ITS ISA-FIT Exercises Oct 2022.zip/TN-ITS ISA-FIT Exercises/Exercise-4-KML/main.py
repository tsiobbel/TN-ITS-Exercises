# Produce a Google Earth KML file to visualize the location of the TN-ITS mutations
# TN-ITS ISA-FIT training 13.10.2022
# Exercise 4 : read csv file and make Google KML file
# Stephen T'Siobbel, ERTICO, 2022
# see tn-its.eu

# string with header of KML file
KML_first_part = """<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://earth.google.com/kml/2.0">
<Document>
  <name>TN-ITS</name>
  <open>1</open>
  <description>TN-ITS DATA</description>
  <Style id="FEATURES">
    <LineStyle>
      <color>ff0000ff</color>
      <width>20</width>
    </LineStyle>
  </Style>
  <Folder>
    <name>Features</name>
    <open>0</open>"""

# string with second part of KML file
KML_start_linestring = """      <Placemark>
        <name>FeatureID</name>
        <description>OpenLR</description>
        <styleUrl>#FEATURES</styleUrl>
        <LineString>
          <extrude>0</extrude>
          <tessellate>1</tessellate>
          <altitudeMode>clampedToGround</altitudeMode>"""

# string with header for each coordinate list
KML_end_linestring = """        </LineString>
      </Placemark>"""

# string with end of KML file
KML_last_part = """   </Folder>
</Document>
</kml>"""

# produce kml file with all coordinates as linestrings as placemarks
def dump_kml(fkml):
    # Using readlines()
    CSVfile = open('RWS-SEP-22.CSV', 'r')
    Lines = CSVfile.readlines()

    # loop over lines in the csv file
    for line in Lines:
        mylist = line.split(',')

        # extract information from list (id, OpenLR binary code, coordinate pairs: lat, long)
        FeatureID =mylist[2]
        OpenLR = mylist[4]
        coordinates = mylist[5]

        # replace header with info from the csv line
        HeaderText = KML_start_linestring.replace("OpenLR",str(OpenLR)).replace("FeatureID",str(FeatureID))

        # dump kml linestring and coordinates info
        print(HeaderText, file=fkml)
        print('            <coordinates>', file=fkml)

        # split the coordinate string in a Python list with separate coordinates
        l = coordinates.split()

        # loop of coordinate pairs until end of the list
        for i in range(0, len(l), 2):
            # Get longitude and latitude
            long = str(l[i + 1])
            lat = str(l[i])

            # write out coordinates and altitude value
            print('              ' + long +',' + lat +',100.0', file=fkml)

        # dump after end of the coordinate list
        print('            </coordinates>', file=fkml)
        print(KML_end_linestring, file=fkml)
    return

# main loop : dump kml file in
with open('RWS-SEP-22.KML', 'w') as f:

    # dump first part of the KML file
    print(KML_first_part, file=f)

    # dump kml string with coordinates extracted from URL
    dump_kml(f)

    # end the kml file
    print(KML_last_part, file=f)

# Parse TN-ITS xml and convert to csv file "tn-its.csv'
# TN-ITS ISA-FIT training 13.10.2022
# Exercise 3 - Parsing
# Stephen T'Siobbel, ERTICO, 2022
# see tn-its.eu

# import library
import xml.etree.ElementTree as ET

# open and read RWS TN-ITS xml file as a single string of text
text_file = open("RWS-SEP-22.XML", "r")
data = text_file.read()
text_file.close()

# filter out namespaces in XML file
xmlstr = data.replace('tnits:','').replace('wfs:','').replace('gml:','')

# get root element of the XML from the element tree
root = ET.fromstring(xmlstr)

# counter
i = 0

# open file to dump results in as csv
f = open("RWS-SEP-22.CSV", "w")

# parse RWS xml file using findall(): search for “all” occurrences that match a given pattern using 'findall', use 'find' for unique elements
for Member in root.findall('member'):
    i += 1
    for RoadFeature in Member.findall('RoadFeature'):
        for Ident in RoadFeature.findall('id'):
            for RFiD in Ident.findall('RoadFeatureId'):
                Prov = RFiD.find('providerId').text
                ProvId = RFiD.find('id').text

        for prop in RoadFeature.findall('properties'):
            for GRSFP in prop.findall('GenericRoadFeatureProperty'):
                Newvalue = GRSFP.find('value').text

        for LocRef in RoadFeature.findall('locationReference'):
            for OLR in LocRef.findall('OpenLRLocationReference'):
                for BLR in OLR.findall('binaryLocationReference'):
                    for BiLR in BLR.findall('BinaryLocationReference'):
                        for BiLR in BLR.findall('BinaryLocationReference'):
                            OpenLR = BiLR.find('base64String').text

        for LocRef in RoadFeature.findall('locationReference'):
            for GLR in LocRef.findall('GeometryLocationReference'):
                for EGEO in GLR.findall('encodedGeometry'):
                    for LSTR in EGEO.findall('LineString'):
                        LocStr = LSTR.find('posList').text

        # write extracted info to csv file
        dumpstr = str(i) +',' + Prov + ',' + ProvId + ',' +Newvalue + ',' +OpenLR + ',' +LocStr + '\n'
        f.write(dumpstr)

# close csv file
f.close()



# Testscript for downloading a TN-ITS XML file
# TN-ITS ISA-FIT training 13.10.2022
# Exercise 1 - Downloading a TN-ITS XML file
# Stephen T'Siobbel, ERTICO, 2022

# Import library
import requests

# select a RWS TN-ITS url
tn_its_url = "https://www.rijkswaterstaat.nl/apps/geoservices/geodata/dmc/tn-its-go/Mutaties/01-09-2022_01-10-2022/delta/delta.gml"

'''
# Here's where the other mutation files are:
tn_its_url = "https://downloads.rijkswaterstaatdata.nl/tn-its-go/Mutaties/01-01-2022_01-02-2022/delta/delta.gml"
tn_its_url = "https://downloads.rijkswaterstaatdata.nl/tn-its-go/Mutaties/01-02-2022_01-03-2022/delta/delta.gml"
tn_its_url = "https://downloads.rijkswaterstaatdata.nl/tn-its-go/Mutaties/01-03-2022_01-04-2022/delta/delta.gml"
tn_its_url = "https://downloads.rijkswaterstaatdata.nl/tn-its-go/Mutaties/01-04-2022_01-05-2022/delta/delta.gml"
tn_its_url = "https://downloads.rijkswaterstaatdata.nl/tn-its-go/Mutaties/01-05-2022_01-06-2022/delta/delta.gml"
tn_its_url = "https://downloads.rijkswaterstaatdata.nl/tn-its-go/Mutaties/01-06-2022_01-07-2022/delta/delta.gml"
tn_its_url = "https://downloads.rijkswaterstaatdata.nl/tn-its-go/Mutaties/01-07-2022_01-08-2022/delta/delta.gml"
tn_its_url = "https://downloads.rijkswaterstaatdata.nl/tn-its-go/Mutaties/01-08-2022_01-09-2022/delta/delta.gml"
tn_its_url = "https://downloads.rijkswaterstaatdata.nl/tn-its-go/Mutaties/01-09-2022_01-10-2022/delta/delta.gml"'''

# API Get request - using requests, the http library; store result in variable
res = requests.get(tn_its_url)

# check for a valid return status = 200
if res.status_code == 200:

    # open file to write tn-its data to
    with open('RWS-SEP-22.XML', 'w') as f:

        # dump file as text
        f.write(res.text)
        f.close()

# signal we're done and output the encoding type (utf8/ISO8859-1)
print("Done! Encoding : ", res.encoding)
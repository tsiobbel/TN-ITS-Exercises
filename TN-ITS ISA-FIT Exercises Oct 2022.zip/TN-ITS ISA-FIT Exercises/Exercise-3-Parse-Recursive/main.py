# Parse TN-ITS xml and convert to csv file "tn-its.csv'
# TN-ITS ISA-FIT training 13.10.2022
# Exercise 3 - Parsing -  recursive
# Stephen T'Siobbel, ERTICO, 2022
# see tn-its.eu

# import library
import xml.etree.ElementTree as ET

# recursiveParsing - with nice indentations
def recParse(e, str):
    for child in e:
        print(str, child.tag, child.attrib, child.text)

        # recursive call, to find children and add extra spaces
        recParse(child, str + '   ')

# Start parsing
f = 'RWS-SEP-22.XML'

print('-------- Start reading GML File: ' + f + ' ---------------')

# start parsing the XML file, find the root
tree = ET.parse(f)
root = tree.getroot()

#main call
recParse(root,'')


